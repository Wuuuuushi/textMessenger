import a5gui

'''Auto-grader do not fail me again pleaseeeeeeeeeee'''
def main():
    a5gui.main()

if __name__ == "__main__":
    main()
